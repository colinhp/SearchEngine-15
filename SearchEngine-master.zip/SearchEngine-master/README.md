# SearchEngine
使用C++语言，实现轻量型搜索引擎的后台服务器；

项目说明文档请见“[轻量型搜索引擎项目文档说明.pdf](https://github.com/tanfy/SearchEngine/blob/master/SearchEngine/Description%20of%20Mini%20SearchEngine%20Program.pdf)”文档:)
