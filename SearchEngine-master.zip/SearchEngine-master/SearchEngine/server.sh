./Bin/Server  /home/fiona/PROJECT@BUAA/c++/SearchEngine/Conf/server.conf
